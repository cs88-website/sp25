def twenty_twenty_five():
    """Come up with the most creative expression that evaluates to 2025
    using only numbers and the +, *, and - operators (or ** and % if you'd like).

    >>> twenty_twenty_five()
    2025
    """
    return 1**3 + 2**3 + 3**3 + 4**3 + 5**3 + 6**3 + 7**3 + 8**3 + 9**3

